from datetime import date, datetime, timedelta

#user story 1, dates before dates
def dates_before_dates(individuals, family):
     current_date = date.today()
     ind_bad_bday = []
     ind_bad_death = []
     fam_bad_marr = []
     fam_bad_div = []
     for ind_obj in individuals:
         if (ind_obj.birthday != None):
             if ind_obj.birthday > current_date:
                 print('ERROR: INDIVIDUAL: US01: [' + ind_obj.IndId + '] :Birthday before current date')
                 ind_bad_bday += [ind_obj.IndId]
         if (ind_obj.death_date != None):
             if ind_obj.death_date > current_date:
                 print('ERROR: INDIVIDUAL: US01: [' + ind_obj.IndId + '] :Deathday before current date')
                 ind_bad_death += [ind_obj.IndId]

     for fam_obj in family:
         if fam_obj.marriage != None:
             if fam_obj.marriage > current_date:
                 print('ERROR: FAMILY: US01: [' + fam_obj.famId + '] :Marriage date before current date')
                 fam_bad_marr += [fam_obj.famId]
                 #if fam_obj.divorce_date != None:
                 #if (fam_obj.divorce_date != None):
                 #if fam_obj.divorce_date > current_date:
                 #print('Error: ' + fam_obj.famId + ' Divorce date before current date')
     return [ind_bad_bday, ind_bad_death, fam_bad_marr, fam_bad_div]

# US09 - Birth before death of parents
def birth_before_death_of_parents(individuals, families):
    US09_flag = True
    error_type = "US09"

    for ind in individuals:

        if len(ind.famc) > 0:
            father = None
            father_id = None
            mother = None
            mother_id = None
            fam = None

            # Get the ID of parents for an individual
            for family in families:
                if family.famId == ind.famc[0]:
                    father_id = family.husbandId
                    mother_id = family.wifeId
                    fam = family
                    break

            # Get the ID of individuals
            for ind in individuals:
                if ind.IndId == father_id:
                    father = ind
                if ind.IndId == mother_id:
                    mother = ind

            if father.death_date is not None and father.death_date < ind.birthday - timedelta(days=266):
                error_location = [fam.famId, ind.IndId]
                print('ERROR: FAMILY : US9: [' + fam.famId + ' , ' + ind.IndId + '] : Born before parents death day ')
                US09_flag = False

            if mother.death_date is not None and mother.death_date < ind.birthday:
                error_location = [fam.uid, ind.uid]
                print('ERROR: FAMILY : US9: [' + ind.IndId + '] : Born before parents death day ')
                US09_flag = False
    return US09_flag


#user story 11, no bigamy
def no_bigamy(individuals, family):
    for ind in individuals:
        marriages = 0
        for f in family:
            if f.husbandId == ind.IndId and currently_married(f, individuals):
                marriages += 1
            elif f.wifeId == ind.IndId and currently_married(f,individuals):
                marriages += 1
        if marriages > 1:
            print('ERROR: FAMILY: US11: ' + ind.name[0] + " is married more to more than one person")

def currently_married(family, individuals):
    if family.divorced != None:
        return False
    hus_id = family.husbandId
    wife_id = family.wifeId
    husband = None
    wife = None
    for i in individuals:
        if wife_id == i.IndId:
            wife = i
        elif hus_id == i.IndId:
            husband = i
    if husband.death_date != None:
        return False
    if wife.death_date != None:
        return False
    return True

#User story 16, male last names
def male_last_names(individuals, family):
    for ind in individuals:
        if ind.gender == "M":
            if len(ind.famc) > 0:
                for famc in ind.famc:
                    for fam in family:
                        if fam.famId == famc:
                            if not ind.name[1] == fam.husband_Name[1]:
                                print('ERROR: FAMILY : US16: [' + ind.IndId + '] :Sons last names should match fathers ')

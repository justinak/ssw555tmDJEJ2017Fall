# user story 18, was to make sure that siblings could not marry each other
def checkIncest(families):
    for family in families:
        for child1 in family.children:
            for child2 in family.children:
                for marriage in families:
                    if child1 == child2:
                        pass
                    elif (child1 == marriage.wifeId or child1 == marriage.husbandId) and (
                            child2 == marriage.wifeId or child2 == marriage.husbandId):
                        print('ERROR: FAMILY: US18: Siblings cannot marry each other')


# user story 21, correct gender roles
def check_genderrole(individuals, families):
    for family in families:
        for individual in individuals:
            if (individual.IndId == family.husbandId and individual.gender != "M"):
                print("ERROR: INDIVIDUAL: US21: Gender role of [" + " ".join(individual.name) + "] does not match")
            elif (individual.IndId == family.wifeId and individual.gender != "F"):
                print("ERROR: INDIVIDUAL: US21: Gender role of [" + " ".join(individual.name) + "] does not match")


def marriage_before_divorce(families):
    Story_name = "US04"
    error_msg = "Marriage should occur before divorce"

    for family in families:
        if family.marriage and family.divorced:
            if family.divorced <= family.marriage:
                location = [family.husbandId, family.wifeId]
                #error = (Story_name, error_msg, location)
                print("ERROR: FAMILY: " + Story_name + ": [" + family.husbandId +" , "+ family.wifeId + "] : " + error_msg)



def marriage_before_death(individuals, families):
    Story_name = "US05"
    error_msg = "Marriage should occur before death"

    for family in families:
        for individual in individuals:
            if individual.IndId in [family.husbandId, family.wifeId] and individual.death_date and family.marriage:
                if individual.death_date <= family.marriage:
                    location = [individual.IndId]
                    #error = (Story_name, error_msg, location)
                    print("ERROR: FAMILY: " + Story_name + ": [" + individual.IndId + "] : " + error_msg)
